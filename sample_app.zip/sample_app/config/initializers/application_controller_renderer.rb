# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '87614fd6f6eed082bb6dbf65187a39ca7c12c4f2bfc784b711049bf3dfb9c55480ed1f3c3618a6c205640181102041404af61487a6d91b5df93903b10411d41f'